import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { User } from 'firebase/auth';
import { Header } from './components/Header';
import { WordCard } from './components/WordCard';
import { StatsDashboard } from './components/StatsDashboard';
import { UsageGuide } from './components/UsageGuide';
import { ChatAssistant } from './components/ChatAssistant';
import { SmartNotebook } from './components/SmartNotebook';
import { SettingsModal } from './components/SettingsModal';
import { BookListModal } from './components/BookListModal';
import { ThesaurusView } from './components/ThesaurusView';
import { QuizView } from './components/QuizView';
import { TrashView } from './components/TrashView';
import { Toast } from './components/Toast';
import { SkeletonLoader } from './components/SkeletonLoader';
import { LoginConfirmModal } from './components/LoginConfirmModal';
import { DomainErrorModal } from './components/DomainErrorModal'; 

import { WordEntry, NoteEntry, BookMetadata, GeminiResponse, WordStatus } from './types';
import { fetchWordDetails } from './services/geminiService';
import { login, loginWithRedirect, logout, subscribeToAuth, dbService, initializationError } from './services/firebase';
import { exportToJSON } from './services/csvExportService';

type ViewMode = 'search' | 'list' | 'chat' | 'notebook' | 'thesaurus' | 'quiz' | 'trash';

// Safe ID generator
const generateId = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Loading Screen Component
const LoadingScreen = () => (
  <div className="min-h-screen flex items-center justify-center bg-slate-50">
    <div className="flex flex-col items-center">
      <div className="w-16 h-16 relative mb-4">
        <div className="absolute inset-0 rounded-full border-4 border-indigo-100"></div>
        <div className="absolute inset-0 rounded-full border-4 border-indigo-600 border-t-transparent animate-spin"></div>
      </div>
      <p className="text-slate-500 font-bold animate-pulse">EtymoLinguaを起動中...</p>
    </div>
  </div>
);

const App: React.FC = () => {
  // --- Hooks Declaration ---
  const [user, setUser] = useState<User | null>(null);
  const [isGlobalLoading, setIsGlobalLoading] = useState(true); // Global Loading State
  const [currentView, setCurrentView] = useState<ViewMode>('search');
  
  // Data
  const [words, setWords] = useState<WordEntry[]>([]);
  const [books, setBooks] = useState<BookMetadata[]>([]);
  const [notes, setNotes] = useState<NoteEntry[]>([]);
  const [currentBookId, setCurrentBookId] = useState<string>('default');

  // Search
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<GeminiResponse | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  // Modals
  const [showUsage, setShowUsage] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showBooks, setShowBooks] = useState(false);
  const [showLoginConfirm, setShowLoginConfirm] = useState(false); 
  const [showDomainError, setShowDomainError] = useState(false); 
  const [isLoggingIn, setIsLoggingIn] = useState(false); 
  
  // Quiz
  const [quizTargetWords, setQuizTargetWords] = useState<WordEntry[]>([]);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error'; isVisible: boolean }>({
    message: '',
    type: 'info',
    isVisible: false
  });

  const showToast = useCallback((message: string, type: 'success' | 'info' | 'error' = 'info') => {
    setToast({ message, type, isVisible: true });
  }, []);

  const hideToast = useCallback(() => {
    setToast(prev => ({ ...prev, isVisible: false }));
  }, []);

  // --- Logic Functions (defined before useEffect to be used inside) ---
  const loadData = useCallback(async (userId: string) => {
    try {
      const data = await dbService.loadAll(userId);
      // Sort words by timestamp desc
      setWords(data.words.sort((a, b) => b.timestamp - a.timestamp));
      setBooks(data.books);
      setNotes(data.notes.sort((a, b) => b.timestamp - a.timestamp));

      // Ensure default book exists if empty
      if (data.books.length === 0) {
        const defaultBook: BookMetadata = {
            id: 'default',
            userId: userId,
            title: 'マイ単語帳',
            description: 'デフォルトの単語帳',
            createdAt: Date.now()
        };
        await dbService.addBook(defaultBook, userId);
        setBooks([defaultBook]);
      }
    } catch (e) {
      console.error(e);
      showToast("データの読み込みに失敗しました", "error");
    }
  }, [showToast]);

  const setupGuestUser = useCallback(() => {
    // Create a mock user object for Guest Mode
    const guestUser = {
        uid: 'guest',
        displayName: 'Guest User',
        email: 'guest@etymolingua.app',
        emailVerified: true,
        isAnonymous: true,
        metadata: {},
        providerData: [],
        refreshToken: '',
        tenantId: null,
        delete: async () => {},
        getIdToken: async () => '',
        getIdTokenResult: async () => ({} as any),
        reload: async () => {},
        toJSON: () => ({}),
        phoneNumber: null,
        providerId: 'guest',
        photoURL: null
    } as unknown as User;
    
    setUser(guestUser);
    loadData('guest').then(() => {
        setIsGlobalLoading(false);
        // Only show toast if we are falling back, not on every refresh if already guest
    });
  }, [loadData]);

  // --- Auth & Data Loading (with Failsafe Timeout) ---
  useEffect(() => {
    let isMounted = true;
    let authUnsubscribe: (() => void) | null = null;

    // 1. Safety Timeout: If Firebase takes too long, force start as Guest
    const safetyTimeout = setTimeout(() => {
      if (isMounted && isGlobalLoading) {
        console.warn("Firebase init timeout: Falling back to Guest Mode.");
        setupGuestUser();
      }
    }, 3000); // 3 seconds timeout

    // 2. Check for Immediate Initialization Error
    if (initializationError) {
       console.warn("Firebase Init Error detected. Starting in Guest Mode.");
       setupGuestUser();
       clearTimeout(safetyTimeout);
       return;
    }

    // 3. Normal Auth Subscription
    try {
      authUnsubscribe = subscribeToAuth(async (currentUser) => {
        if (!isMounted) return;
        clearTimeout(safetyTimeout); // Auth responded, cancel timeout
        
        // Guest logic: do not override if already in guest mode and no official user
        if (user?.uid === 'guest' && !currentUser) {
            setIsGlobalLoading(false);
            return;
        }

        setUser(currentUser);
        
        if (currentUser) {
          try {
              await loadData(currentUser.uid);
          } catch(e) {
              console.error("Data load error:", e);
          }
        } else if (user?.uid !== 'guest') {
          // Clear data on logout
          setWords([]);
          setBooks([]);
          setNotes([]);
        }
        
        setIsGlobalLoading(false);
      });
    } catch (e) {
      console.error("Subscribe Auth Error:", e);
      setupGuestUser(); // Fallback on error
      clearTimeout(safetyTimeout);
    }

    return () => {
        isMounted = false;
        clearTimeout(safetyTimeout);
        if (authUnsubscribe) authUnsubscribe();
    };
  }, []); // Run once

  // Trigger Confirmation Modal
  const requestLogin = () => {
    setShowLoginConfirm(true);
  };

  // Execute Actual Login
  const performLogin = async (method: 'popup' | 'redirect') => {
    setIsLoggingIn(true);
    try {
      if (method === 'popup') {
        await login();
        // Success: Close modal and show success toast (Redirect doesn't reach here immediately)
        setShowLoginConfirm(false);
        showToast('ログインしました', 'success');
      } else {
        await loginWithRedirect();
        // Redirect happens, page unloads.
      }
    } catch (e: any) {
      // Failure: Close modal immediately
      setShowLoginConfirm(false);

      // Don't log expected domain errors as failures
      if (e.code !== 'auth/unauthorized-domain' && !e.message?.includes('auth/unauthorized-domain')) {
          console.error("Login Error:", e);
      }
      
      // Handle Firebase Config Not Set
      if (e.message && e.message.includes("Firebaseの設定が完了していません")) {
        alert("【設定エラー】\nFirebaseの設定がまだ完了していません。\n\n`services/firebase.ts` ファイルを開き、ご自身のFirebaseプロジェクトの設定情報（firebaseConfig）を記述してください。");
        return;
      }

      // Handle Popup Blocked
      if (e.code === 'auth/popup-blocked') {
        alert("【ポップアップがブロックされました】\nリダイレクトログインをお試しいただくか、ブラウザの設定でポップアップを許可してください。");
        return;
      }

      // Handle Unauthorized Domain Error using custom Modal
      if (e.code === 'auth/unauthorized-domain' || (e.message && e.message.includes('auth/unauthorized-domain'))) {
        setShowDomainError(true);
      } else {
        showToast(`ログインに失敗しました: ${e.message}`, 'error');
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGuestLogin = () => {
    setIsGlobalLoading(true); 
    setupGuestUser();
    showToast('ゲストモードで開始しました（データはブラウザに保存されます）', 'info');
  };

  const handleLogout = async () => {
    setIsGlobalLoading(true);
    if (user?.uid === 'guest') {
        setUser(null);
        setWords([]);
        setBooks([]);
        setNotes([]);
        showToast('ゲストモードを終了しました', 'info');
        setIsGlobalLoading(false);
    } else {
        await logout();
        showToast('ログアウトしました', 'info');
        // Loading state will be handled by onAuthStateChanged
    }
  };

  // Search Logic
  const handleSearch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setSearchResult(null);
    try {
        const result = await fetchWordDetails(searchQuery);
        setSearchResult(result);
    } catch (e: any) {
        showToast(e.message || "検索に失敗しました", 'error');
    } finally {
        setIsSearching(false);
    }
  };

  const handleAddWord = async (geminiData: GeminiResponse) => {
    // Allow guest user to save
    if (!user) {
        showToast('単語を保存するにはログインするかゲストモードを開始してください', 'info');
        return;
    }
    
    const newWord: WordEntry = {
        ...geminiData,
        id: generateId(),
        userId: user.uid,
        bookId: currentBookId,
        timestamp: Date.now(),
        status: 'unknown',
        isTrashed: false,
        // SRS Defaults
        nextReviewDate: Date.now(),
        interval: 0,
        easeFactor: 2.5,
        streak: 0
    };

    setWords(prev => [newWord, ...prev]);
    await dbService.addWord(newWord, user.uid);
    showToast(`「${newWord.word}」を保存しました`, 'success');
    setSearchQuery('');
    setSearchResult(null);
  };

  // Word Actions
  const handleStatusChange = async (id: string, status: WordStatus, srsUpdates?: Partial<WordEntry>) => {
    if (!user) return;
    setWords(prev => prev.map(w => w.id === id ? { ...w, status, ...srsUpdates } : w));
    await dbService.updateWord(id, { status, ...srsUpdates }, user.uid);
  };

  const moveToTrash = async (id: string) => {
    if (!user) return;
    setWords(prev => prev.map(w => w.id === id ? { ...w, isTrashed: true } : w));
    await dbService.deleteWord(id);
    showToast('ゴミ箱に移動しました', 'info');
  };

  const restoreFromTrash = async (id: string) => {
    if (!user) return;
    setWords(prev => prev.map(w => w.id === id ? { ...w, isTrashed: false } : w));
    await dbService.restoreWord(id);
    showToast('復元しました', 'success');
  };

  const deletePermanently = async (id: string) => {
    if (!user) return;
    setWords(prev => prev.filter(w => w.id !== id));
    await dbService.permanentDeleteWord(id);
    showToast('完全に削除しました', 'success');
  };

  const emptyTrash = async () => {
      if (!user) return;
      const trashIds = words.filter(w => w.isTrashed).map(w => w.id);
      setWords(prev => prev.filter(w => !w.isTrashed));
      
      // Async batch delete
      trashIds.forEach(id => dbService.permanentDeleteWord(id));
      showToast('ゴミ箱を空にしました', 'success');
  };

  // Note Actions
  const handleSaveNote = async (title: string, content: string, tags: string[]) => {
      if (!user) return;
      const newNote: NoteEntry = {
          id: generateId(),
          userId: user.uid,
          title,
          content,
          tags,
          timestamp: Date.now(),
          isTrashed: false
      };
      setNotes(prev => [newNote, ...prev]);
      await dbService.addNote(newNote, user.uid);
      showToast('ノートを保存しました', 'success');
  };

  const handleDeleteNote = async (id: string) => {
      if (!user) return;
      setNotes(prev => prev.filter(n => n.id !== id));
      await dbService.permanentDeleteNote(id);
      showToast('ノートを削除しました', 'info');
  };

  // Book Actions
  const handleCreateBook = async (title: string, description: string) => {
      if (!user) return;
      const newBook: BookMetadata = {
          id: generateId(),
          userId: user.uid,
          title,
          description,
          createdAt: Date.now()
      };
      setBooks(prev => [...prev, newBook]);
      await dbService.addBook(newBook, user.uid);
      showToast(`単語帳「${title}」を作成しました`, 'success');
  };

  const handleSelectBook = (id: string) => {
      setCurrentBookId(id);
      setShowBooks(false);
      showToast('単語帳を切り替えました', 'info');
  };
  
  const handleDeleteBook = async (id: string) => {
      if (!user) return;
      // Filter out words belonging to this book
      setWords(prev => prev.filter(w => w.bookId !== id));
      setBooks(prev => prev.filter(b => b.id !== id));
      await dbService.deleteBook(id);
      
      if (currentBookId === id) {
          setCurrentBookId('default');
      }
      showToast('単語帳を削除しました', 'success');
  };

  const handleRenameBook = async (id: string, newTitle: string) => {
      if (!user) return;
      setBooks(prev => prev.map(b => b.id === id ? { ...b, title: newTitle } : b));
      await dbService.updateBook(id, { title: newTitle }, user.uid);
      showToast('単語帳名を変更しました', 'success');
  };

  // Filtered Data
  const activeWords = useMemo(() => {
    let filtered = words.filter(w => !w.isTrashed);
    // If not "All Words" view (represented by special ID 'all'), filter by book
    if (currentBookId !== 'all') {
        filtered = filtered.filter(w => w.bookId === currentBookId);
    }
    return filtered;
  }, [words, currentBookId]);

  const trashWords = useMemo(() => words.filter(w => w.isTrashed), [words]);

  const currentBookName = useMemo(() => {
      if (currentBookId === 'all') return 'すべての単語';
      const book = books.find(b => b.id === currentBookId);
      return book ? book.title : '単語帳未選択';
  }, [books, currentBookId]);

  // Import/Export Handlers
  const handleExport = () => exportToJSON(activeWords);
  const handleImport = async (file: File) => {
      if (!user) return;
      const reader = new FileReader();
      reader.onload = async (e) => {
          try {
              const content = e.target?.result as string;
              const data = JSON.parse(content);
              // Simple check if it's an array of words
              if (Array.isArray(data)) {
                 const importedWords = data.map((item: any) => ({
                     ...item,
                     id: item.id || generateId(), // ensure ID
                     userId: user.uid,
                     bookId: currentBookId === 'all' ? 'default' : currentBookId, // assign to current book
                     timestamp: item.timestamp || Date.now(),
                     status: item.status || 'unknown'
                 }));
                 
                 setWords(prev => [...importedWords, ...prev]);
                 await dbService.saveWordsBatch(importedWords, user.uid);
                 showToast(`${importedWords.length}語をインポートしました`, 'success');
              }
          } catch(err) {
              showToast('ファイルの読み込みに失敗しました', 'error');
          }
      };
      reader.readAsText(file);
  };
  
  const handleLoadPresetBook = async (bookData: any[]) => {
      if (!user) return;
      const importedWords = bookData.map((item: any) => ({
            ...item,
            id: generateId(),
            userId: user.uid,
            bookId: currentBookId === 'all' ? 'default' : currentBookId,
            timestamp: Date.now(),
            status: 'unknown'
      }));
      setWords(prev => [...importedWords, ...prev]);
      await dbService.saveWordsBatch(importedWords, user.uid);
      showToast(`${importedWords.length}語を追加しました`, 'success');
  };

  // --- Show Loading Screen while initializing ---
  if (isGlobalLoading) {
    return <LoadingScreen />;
  }

  // Note: We removed the `if (initializationError)` block. 
  // If initializationError existed, the effect defaulted to Guest Mode, so we just render the app normally.

  // View Routing
  const renderView = () => {
    switch (currentView) {
      case 'search':
        return (
          <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-300">
             <div className="text-center py-10">
                <h2 className="text-3xl font-extrabold text-slate-900 mb-4">What do you want to learn?</h2>
                <form onSubmit={handleSearch} className="relative max-w-lg mx-auto">
                    <input 
                        type="text" 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="英単語または熟語を入力..." 
                        className="w-full pl-6 pr-14 py-4 rounded-full border-2 border-slate-200 focus:border-indigo-500 focus:outline-none shadow-sm text-lg transition-colors"
                        disabled={isSearching}
                    />
                    <button 
                        type="submit"
                        disabled={isSearching || !searchQuery.trim()}
                        className="absolute right-2 top-2 w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white hover:bg-indigo-700 transition-colors disabled:bg-slate-300"
                    >
                        {isSearching ? <i className="fa-solid fa-spinner animate-spin"></i> : <i className="fa-solid fa-arrow-right"></i>}
                    </button>
                </form>
             </div>

             {searchResult && (
                 <div className="mb-20">
                     <WordCard 
                        word={{ ...searchResult, id: 'temp', timestamp: Date.now(), status: 'unknown' } as WordEntry}
                     />
                     <button 
                        onClick={() => handleAddWord(searchResult)}
                        className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-indigo-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-indigo-700 transition-all active:scale-95 flex items-center gap-2 z-50"
                     >
                         <i className="fa-solid fa-plus"></i> 単語帳に追加
                     </button>
                 </div>
             )}
             
             {isSearching && <SkeletonLoader />}
             
             {!searchResult && !isSearching && (
                 <StatsDashboard 
                    history={activeWords} 
                    onStartDailyQuiz={(targetWords) => {
                        setQuizTargetWords(targetWords);
                        setCurrentView('quiz');
                    }}
                 />
             )}
          </div>
        );
      case 'list':
        return (
          <div className="space-y-6 animate-in fade-in duration-300 pb-20">
             <div className="flex justify-between items-center">
                 <h2 className="text-xl font-bold text-slate-800">
                    <i className="fa-solid fa-list-ul mr-2 text-indigo-500"></i>
                    単語リスト ({activeWords.length})
                 </h2>
             </div>
             {activeWords.length === 0 ? (
                 <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 text-slate-400">
                     単語がありません。検索して追加しましょう！
                 </div>
             ) : (
                 <div className="grid grid-cols-1 gap-6">
                     {activeWords.map(word => (
                         <WordCard 
                            key={word.id} 
                            word={word} 
                            onDelete={moveToTrash}
                            onStatusChange={handleStatusChange}
                            onSearchRelated={(term) => {
                                setSearchQuery(term);
                                setCurrentView('search');
                                handleSearch();
                            }}
                         />
                     ))}
                 </div>
             )}
          </div>
        );
      case 'chat':
          return (
              <ChatAssistant 
                 onSaveNote={handleSaveNote}
                 wordHistory={activeWords.slice(0, 50)} // limit context
              />
          );
      case 'notebook':
          return (
              <SmartNotebook 
                 notes={notes}
                 onDeleteNote={handleDeleteNote}
              />
          );
      case 'thesaurus':
          return (
              <ThesaurusView 
                 history={activeWords}
                 onSearch={(term) => {
                    setSearchQuery(term);
                    setCurrentView('search');
                    handleSearch();
                 }}
              />
          );
      case 'quiz':
          return (
              <QuizView 
                 history={activeWords}
                 onUpdateStatus={handleStatusChange}
                 onExit={() => {
                     setCurrentView('search');
                     setQuizTargetWords([]);
                 }}
                 preselectedWords={quizTargetWords}
              />
          );
      case 'trash':
          return (
              <TrashView 
                 trashHistory={trashWords}
                 onRestore={restoreFromTrash}
                 onDeletePermanently={deletePermanently}
                 onEmptyTrash={emptyTrash}
                 onClose={() => setCurrentView('list')}
              />
          );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800">
      <Header 
        currentView={currentView}
        onChangeView={setCurrentView}
        onOpenUsage={() => setShowUsage(true)}
        onOpenSettings={() => setShowSettings(true)}
        onOpenBooks={() => setShowBooks(true)}
        currentBookName={currentBookName}
        user={user}
        onLogin={requestLogin} // Changed to requestLogin to show Modal first
        onLogout={handleLogout}
      />
      
      <main className="max-w-4xl mx-auto px-4 py-6">
        {user ? renderView() : (
           <div className="text-center py-20 animate-in fade-in zoom-in px-4">
               {/* Logo & Title */}
               <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6 text-indigo-600 shadow-lg shadow-indigo-200">
                   <i className="fa-solid fa-book-sparkles text-4xl"></i>
               </div>
               <h1 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">EtymoLingua</h1>
               <p className="text-slate-500 mb-8 max-w-md mx-auto text-sm sm:text-base leading-relaxed">
                   語源で深く理解し、AIと対話して定着させる。<br/>
                   新しい時代の英語学習プラットフォーム。
               </p>
               
               <div className="flex flex-col gap-4 max-w-xs mx-auto mb-12">
                   <button 
                      onClick={requestLogin} // Changed to requestLogin
                      className="bg-indigo-600 text-white px-8 py-3.5 rounded-xl font-bold shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center gap-2"
                   >
                       <i className="fa-brands fa-google"></i>
                       Googleでログインして始める
                   </button>
                   
                   {/* Guest Mode Button */}
                   <button 
                      onClick={handleGuestLogin}
                      className="bg-white text-slate-600 px-8 py-3 rounded-xl font-bold border-2 border-slate-200 hover:border-indigo-300 hover:text-indigo-600 hover:bg-indigo-50 transition-all active:scale-95 flex items-center justify-center gap-2"
                   >
                       <i className="fa-solid fa-user-secret"></i>
                       ゲストとして試す（登録不要）
                   </button>
               </div>

               {/* Visual Help for Preview Environment */}
               <div className="max-w-xs mx-auto bg-white border border-slate-200 rounded-2xl p-5 shadow-sm relative text-left">
                   <div className="absolute -top-3 left-4 bg-amber-100 text-amber-700 text-[10px] font-bold px-2 py-1 rounded-full border border-amber-200">
                     <i className="fa-solid fa-triangle-exclamation mr-1"></i>プレビュー環境の方へ
                   </div>
                   
                   <p className="text-xs text-slate-600 mb-4 leading-relaxed mt-2">
                     プレビュー画面ではGoogleログインがブロックされることがあります。<br/>
                     その場合は<strong>「ゲストとして試す」</strong>ボタンを使ってください。
                   </p>
               </div>
           </div>
        )}
      </main>

      {/* Modals */}
      <UsageGuide isOpen={showUsage} onClose={() => setShowUsage(false)} />
      
      <SettingsModal 
         isOpen={showSettings}
         onClose={() => setShowSettings(false)}
         onExportJSON={handleExport}
         onImportJSON={handleImport}
         onLoadBook={handleLoadPresetBook}
         wordCount={words.length}
      />

      <BookListModal 
         isOpen={showBooks}
         onClose={() => setShowBooks(false)}
         books={books}
         currentBookId={currentBookId}
         onSelectBook={handleSelectBook}
         onCreateBook={handleCreateBook}
         onDeleteBook={handleDeleteBook}
         onRenameBook={handleRenameBook}
         allBookId="all"
         allWordsCount={words.filter(w => !w.isTrashed).length}
      />

      <Toast 
         message={toast.message}
         type={toast.type}
         isVisible={toast.isVisible}
         onClose={hideToast}
      />

      <LoginConfirmModal 
        isOpen={showLoginConfirm}
        onClose={() => setShowLoginConfirm(false)}
        onConfirm={() => performLogin('popup')}
        onRedirectConfirm={() => performLogin('redirect')}
        isLoading={isLoggingIn}
      />
      
      <DomainErrorModal 
        isOpen={showDomainError}
        onClose={() => setShowDomainError(false)}
        domain={window.location.host || ''}
      />
    </div>
  );
};

export default App;