import React from 'react';
import { User } from 'firebase/auth';

type ViewMode = 'search' | 'list' | 'chat' | 'notebook' | 'thesaurus' | 'quiz' | 'trash';

interface HeaderProps {
  currentView: ViewMode;
  onChangeView: (view: ViewMode) => void;
  onOpenUsage: () => void;
  onOpenSettings: () => void;
  onOpenBooks: () => void;
  currentBookName: string;
  user: User | null;
  onLogin: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  currentView, onChangeView, onOpenUsage, onOpenSettings, onOpenBooks, currentBookName, user, onLogin, onLogout
}) => {
  const getButtonClass = (view: ViewMode) => `px-4 py-2 text-sm font-bold rounded-full transition-all flex items-center gap-2 ${
    currentView === view 
      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
      : 'text-slate-500 hover:text-indigo-600 hover:bg-indigo-50'
  }`;

  return (
    <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50 transition-all">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Logo & Book Switcher */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => onChangeView('search')}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity focus:outline-none"
          >
            <div className="bg-indigo-600 p-2 rounded-lg shadow-md shadow-indigo-200 hidden sm:block">
              <i className="fa-solid fa-book-sparkles text-white text-xl"></i>
            </div>
          </button>

          {/* Book Switcher Button */}
          {user && (
            <button
              onClick={onOpenBooks}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-indigo-50 border border-transparent hover:border-indigo-200 rounded-xl transition-all group"
              title="単語帳を切り替える"
            >
              <i className="fa-solid fa-book text-slate-400 group-hover:text-indigo-500"></i>
              <span className="font-bold text-slate-700 group-hover:text-indigo-700 text-sm max-w-[120px] sm:max-w-[200px] truncate">
                {currentBookName}
              </span>
              <i className="fa-solid fa-chevron-down text-xs text-slate-400 group-hover:text-indigo-400"></i>
            </button>
          )}
        </div>
        
        {/* Desktop Navigation */}
        {user && (
          <nav className="hidden md:flex items-center gap-2">
            <button 
              onClick={() => onChangeView('search')}
              className={getButtonClass('search')}
            >
              <i className="fa-solid fa-magnifying-glass"></i>辞典
            </button>
            <button 
              onClick={() => onChangeView('list')}
              className={getButtonClass('list')}
            >
              <i className="fa-solid fa-list-ul"></i>単語帳
            </button>
            <button 
              onClick={() => onChangeView('quiz')}
              className={getButtonClass('quiz')}
            >
              <i className="fa-solid fa-layer-group"></i>クイズ
            </button>
            <button 
              onClick={() => onChangeView('thesaurus')}
              className={getButtonClass('thesaurus')}
            >
              <i className="fa-solid fa-diagram-project"></i>類語
            </button>
            <div className="w-px h-6 bg-slate-200 mx-1"></div>
            <button 
              onClick={() => onChangeView('chat')}
              className={getButtonClass('chat')}
            >
              <i className="fa-solid fa-comments"></i>Chat
            </button>
            <button 
              onClick={() => onChangeView('notebook')}
              className={getButtonClass('notebook')}
            >
              <i className="fa-solid fa-book-bookmark"></i>Note
            </button>
          </nav>
        )}

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {user ? (
            <>
              <button 
                onClick={() => onChangeView('trash')}
                className={`px-3 py-2 transition-colors ${currentView === 'trash' ? 'text-red-500 bg-red-50 rounded-lg' : 'text-slate-400 hover:text-red-500'}`}
                title="ゴミ箱"
              >
                <i className="fa-solid fa-trash-can text-lg"></i>
              </button>
              
              <button 
                onClick={onOpenSettings}
                className="px-3 py-2 text-slate-400 hover:text-indigo-600 transition-colors flex items-center gap-1"
                title="設定・データ管理"
              >
                <i className="fa-solid fa-gear text-lg"></i>
              </button>

              <div className="w-px h-6 bg-slate-200 mx-1"></div>

              <div className="flex items-center gap-2 group relative">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="User" className="w-8 h-8 rounded-full border border-slate-200" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                    {user.email?.[0]?.toUpperCase() || 'U'}
                  </div>
                )}
                <button 
                  onClick={onLogout}
                  className="hidden group-hover:flex absolute top-10 right-0 w-24 bg-white border border-slate-200 shadow-lg rounded-lg py-2 px-3 text-xs font-bold text-red-500 hover:bg-red-50 justify-center items-center gap-1"
                >
                  <i className="fa-solid fa-right-from-bracket"></i> ログアウト
                </button>
              </div>
            </>
          ) : (
            <button
              onClick={onLogin}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold text-sm shadow-md shadow-indigo-200 transition-all flex items-center gap-2"
            >
              <i className="fa-brands fa-google"></i>
              ログイン
            </button>
          )}
          
          <div className="w-px h-6 bg-slate-200 mx-1"></div>
           <button 
            onClick={onOpenUsage}
            className="px-3 py-2 text-slate-400 hover:text-indigo-600 transition-colors"
            title="使い方"
          >
            <i className="fa-regular fa-circle-question text-lg"></i>
          </button>
        </div>
      </div>
      
      {/* Mobile Nav */}
      {user && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around p-2 z-50 pb-safe overflow-x-auto">
          <button onClick={() => onChangeView('search')} className={`flex flex-col items-center p-2 min-w-[3.5rem] rounded-xl ${currentView === 'search' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
            <i className="fa-solid fa-magnifying-glass text-lg mb-1"></i>
            <span className="text-[10px] font-bold">辞典</span>
          </button>
          <button onClick={() => onChangeView('list')} className={`flex flex-col items-center p-2 min-w-[3.5rem] rounded-xl ${currentView === 'list' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
            <i className="fa-solid fa-list-ul text-lg mb-1"></i>
            <span className="text-[10px] font-bold">単語帳</span>
          </button>
          <button onClick={() => onChangeView('quiz')} className={`flex flex-col items-center p-2 min-w-[3.5rem] rounded-xl ${currentView === 'quiz' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
            <i className="fa-solid fa-layer-group text-lg mb-1"></i>
            <span className="text-[10px] font-bold">クイズ</span>
          </button>
          <button onClick={() => onChangeView('chat')} className={`flex flex-col items-center p-2 min-w-[3.5rem] rounded-xl ${currentView === 'chat' ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400'}`}>
            <i className="fa-solid fa-comments text-lg mb-1"></i>
            <span className="text-[10px] font-bold">AI会話</span>
          </button>
          <button onClick={() => onChangeView('trash')} className={`flex flex-col items-center p-2 min-w-[3.5rem] rounded-xl ${currentView === 'trash' ? 'text-red-500 bg-red-50' : 'text-slate-400'}`}>
            <i className="fa-solid fa-trash-can text-lg mb-1"></i>
            <span className="text-[10px] font-bold">ゴミ箱</span>
          </button>
        </div>
      )}
    </header>
  );
};