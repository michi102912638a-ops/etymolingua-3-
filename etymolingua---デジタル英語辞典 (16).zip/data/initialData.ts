import { WordEntry } from '../types';

export const RESTORED_BACKUP: WordEntry[] = [
  {
    "word": "mass",
    "meaning": "塊、質量、大衆、多量、（キリスト教の）ミサ",
    "pronunciation": "マス [mæs]",
    "etymology": "「塊」としての意味は、ラテン語のmassa（練られたパン生地、塊）から来ており、さらに遡るとギリシャ語のmaza（大麦のケーキ、パン生地）に由来します。一方で、キリスト教の「ミサ」としての意味は、ラテン語のmissa（解散、送り出すこと）が語源であり、礼拝の最後に「Ite, missa est（行きなさい、解散です）」と告げられたことに由来する、全く別の語源を持つ同形異義語です。",
    "mnemonic": "「マッサージ (massage)」を思い浮かべてください。筋肉の塊を揉みほぐすイメージです。また、マスコミ（mass communication）の「マス」は「大衆（人の塊）」を指すと覚えましょう。",
    "logic": "核となるイメージは「不定形のものが集まった大きな一塊」です。パン生地のように、こねて一つにまとまった状態を指します。そこから、物理学では「物質の量（質量）」、社会学では個性を失った「人々の集まり（大衆）」、一般的には「大量のもの」へと意味が転じました。宗教のミサについては、儀式の終了（解散）を告げる言葉が、儀式そのものを指す名詞に変化したという歴史的経緯があります。",
    "exampleSentence": "The dark clouds formed a solid mass across the sky.",
    "exampleSentenceTranslation": "暗い雲が空一面に厚い塊となって広がった。",
    "synonyms": [
      {
        "term": "lump",
        "translation": "（小さな）塊"
      },
      {
        "term": "bulk",
        "translation": "大半、かさ、巨体"
      },
      {
        "term": "multitude",
        "translation": "多数、群衆"
      }
    ],
    "collocations": [
      {
        "term": "mass production",
        "translation": "大量生産"
      },
      {
        "term": "mass media",
        "translation": "マスメディア"
      },
      {
        "term": "critical mass",
        "translation": "臨界量、必要な最小限の量"
      }
    ],
    "derivatives": [
      "massive",
      "massively",
      "massiveness"
    ],
    "idioms": [
      {
        "term": "the masses",
        "translation": "一般大衆、庶民"
      },
      {
        "term": "in the mass",
        "translation": "全体として、ひとまとめに"
      },
      {
        "term": "land mass",
        "translation": "大陸、広大な土地"
      }
    ],
    "nuance": "物理的な「重さ (weight)」が重力の影響を含むのに対し、「質量 (mass)」は場所によらない物質そのものの量を指します。また「大衆 (the masses)」として使われる場合、エリート層と対比された「個別の顔が見えない集団」という、やや突き放したニュアンスが含まれることがあります。",
    "relatedWords": [
      {
        "term": "massage",
        "translation": "マッサージ（語源を同じくする「揉む」動作）"
      },
      {
        "term": "amass",
        "translation": "蓄積する（一塊にする）"
      },
      {
        "term": "dismiss",
        "translation": "解散させる（ミサと同じmissaに由来）"
      }
    ],
    "id": "eee12210-f5a3-463f-8f54-7233cea0dfde",
    "bookId": "eiken-pre-1",
    "timestamp": 1769819478870,
    "status": "unknown",
    "isTrashed": false,
    "nextReviewDate": 1769819478870,
    "interval": 0,
    "easeFactor": 2.5,
    "streak": 0
  },
  {
    "word": "certainly",
    "meaning": "確実に、確かに、（返事として）承知しました",
    "pronunciation": "サーテンリー [ˈsɜːrtnli]",
    "etymology": "ラテン語で「ふるいにかける、区別する、判断する」を意味する「cernere」が語源です。この言葉の過去分詞形である「certus（決定された、確実な）」からフランス語の「certain」が生まれ、そこに副詞を作る接尾辞「-ly」が結びつきました。",
    "mnemonic": "「さあ（Cer）、店（tain）員に聞けば『確実に』わかる」とイメージしましょう。",
    "logic": "「ふるいにかける（cernere）」という行為は、多くの選択肢の中から正しいものを選び出し、不確かなものを取り除く作業を指します。ふるいにかけられ、残った「選び抜かれたもの」は疑いようがないため、「certus（確実な）」という意味になりました。certainlyは、その「疑いがない状態」で物事を行う、あるいは述べることが核心にあります。",
    "exampleSentence": "I will certainly pass your message to the manager as soon as he returns.",
    "exampleSentenceTranslation": "マネージャーが戻り次第、必ずあなたのご伝言をお伝えいたします。",
    "synonyms": [
      {
        "term": "definitely",
        "translation": "間違いなく（確信が強い）"
      },
      {
        "term": "surely",
        "translation": "確かに（話し手の確信や期待）"
      },
      {
        "term": "absolutely",
        "translation": "完全に、その通り（100%の同意）"
      }
    ],
    "collocations": [
      {
        "term": "almost certainly",
        "translation": "ほぼ確実に"
      },
      {
        "term": "certainly not",
        "translation": "決して〜ない（強い否定）"
      },
      {
        "term": "most certainly",
        "translation": "間違いなく（強調）"
      }
    ],
    "derivatives": [
      "certain",
      "certainty",
      "ascertain",
      "uncertain",
      "uncertainty"
    ],
    "idioms": [
      {
        "term": "for certain",
        "translation": "確かに、はっきりと"
      },
      {
        "term": "make certain",
        "translation": "確かめる、確実にする"
      }
    ],
    "nuance": "「Of course」は「当たり前でしょ」という当然の理屈を感じさせることがありますが、「Certainly」はより丁寧で客観的な響きがあります。また、接客などで「かしこまりました」と答える際は、sureよりもプロフェッショナルでフォーマルな印象を与えます。",
    "relatedWords": [
      {
        "term": "discern",
        "translation": "見分ける（dis=離して ＋ cern=ふるいにかける）"
      },
      {
        "term": "concern",
        "translation": "関わる、心配させる（con=共に ＋ cern=ふるいにかける）"
      },
      {
        "term": "certificate",
        "translation": "証明書（確実なものにするもの）"
      }
    ],
    "id": "ce0605f6-4c1c-4fd4-860e-d4c6e7413661",
    "bookId": "eiken-pre-1",
    "timestamp": 1769819378553,
    "status": "unknown",
    "isTrashed": false,
    "nextReviewDate": 1769819378553,
    "interval": 0,
    "easeFactor": 2.5,
    "streak": 0
  },
  {
    "id": "8c0fdaf3-be75-49e0-89bf-df7d7e8a48a4",
    "bookId": "120be0bf-6150-4d10-8e1c-6fa237330f52",
    "word": "convince",
    "meaning": "納得させる、確信させる",
    "pronunciation": "コンヴィンス [kənˈvɪns]",
    "etymology": "ラテン語の「convincere」が語源。「con-（完全に、強調）」＋「vincere（征服する、打ち勝つ）」というパーツで構成されています。",
    "mnemonic": "「完全に(con)勝利(vince)して、相手の疑念をねじ伏せる」というイメージ。",
    "logic": "もともとは法廷などで証拠を突きつけ、相手の誤りを「打ち負かす（征服する）」ことで真実を認めさせるという意味でした。力による征服ではなく、論理や証拠によって相手の「疑う心」を完全に克服し、思考をこちら側に引き寄せる（＝納得させる）という歴史的背景があります。",
    "exampleSentence": "It took hours to convince him that the plan was feasible.",
    "exampleSentenceTranslation": "その計画が実行可能であることを彼に納得させるのに数時間かかった。",
    "synonyms": [
      {
        "term": "persuade",
        "translation": "説得する（行動を促すニュアンスが強い）"
      },
      {
        "term": "assure",
        "translation": "確信させる、保証する"
      },
      {
        "term": "satisfy",
        "translation": "納得させる、満足させる"
      }
    ],
    "collocations": [
      {
        "term": "convince someone of something",
        "translation": "人に〜を納得させる"
      },
      {
        "term": "hard to convince",
        "translation": "納得させるのが難しい"
      },
      {
        "term": "fully convinced",
        "translation": "完全に確信している"
      }
    ],
    "derivatives": [
      "conviction",
      "convincing",
      "convincingly"
    ],
    "idioms": [
      {
        "term": "convince someone otherwise",
        "translation": "人にそれとは違う（反対の）ことを納得させる"
      }
    ],
    "nuance": "convinceは「（証拠や論理で）信じさせる」という「思考の変化」に重きを置きます。対してpersuadeは「（説得して）行動させる」という「行動の変化」を促す文脈でよく使われます。",
    "relatedWords": [
      {
        "term": "victory",
        "translation": "勝利（vince = 打ち勝つ）"
      },
      {
        "term": "invincible",
        "translation": "無敵の（征服できない）"
      },
      {
        "term": "convict",
        "translation": "有罪を宣告する（法廷で打ち負かす）"
      }
    ],
    "timestamp": 1769162800830,
    "status": "learning",
    "isTrashed": false,
    "nextReviewDate": 1769659836499,
    "interval": 0,
    "easeFactor": 2.5,
    "streak": 0
  }
];