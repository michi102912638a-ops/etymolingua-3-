
export const TECH_WORDS = [
  {
    "word": "algorithm",
    "meaning": "アルゴリズム、計算手順、処理手順",
    "pronunciation": "アルゴリズム [ˈælɡərɪðəm]",
    "etymology": "9世紀のペルシャの数学者「アル＝フワーリズミー（Al-Khwarizmi）」の名前に由来。彼が書いた数学書が語源。",
    "mnemonic": "「ある(Al) ゴリ(gori)ラの リズム(thm)感」→ 手順通りに踊るゴリラを想像。",
    "logic": "数学者の名前がラテン語化され「algorismus」となり、それが「計算手法」を指すようになりました。現在では、問題を解決するための明確な「一連の手順・ルール」を指します。",
    "exampleSentence": "Search engines use complex algorithms to rank websites.",
    "exampleSentenceTranslation": "検索エンジンはウェブサイトを順位付けするために複雑なアルゴリズムを使用している。",
    "synonyms": [
      { "term": "procedure", "translation": "手順" },
      { "term": "process", "translation": "工程" },
      { "term": "formula", "translation": "公式" }
    ],
    "collocations": [
      { "term": "sorting algorithm", "translation": "ソートアルゴリズム" },
      { "term": "encryption algorithm", "translation": "暗号化アルゴリズム" }
    ],
    "derivatives": ["algorithmic"],
    "idioms": [],
    "nuance": "単なる「方法」ではなく、入力に対して必ず決まった出力を返すための「数学的・論理的なルールの集合」という厳密なニュアンスがあります。",
    "relatedWords": [
      { "term": "arithmetic", "translation": "算数（語源は異なるが音が似て混同され、意味が融合した経緯がある）" },
      { "term": "algebra", "translation": "代数学（同じ数学者の著書名に由来）" }
    ],
    "id": "tech-algo-001",
    "timestamp": 1700000000001,
    "status": "unknown"
  },
  {
    "word": "deprecated",
    "meaning": "非推奨の、廃止予定の",
    "pronunciation": "デプリケイティド [ˈdeprəkeɪtɪd]",
    "etymology": "ラテン語の de-（離れて）+ precari（祈る）が語源。「（災害などが）去るように祈る」→「好ましくないとして反対する」。",
    "mnemonic": "「デブ(dep)のリカ(reca)ちゃんは、ダイエット中でケーキ非推奨(ted)」",
    "logic": "元々は「〜に反対を唱える」という意味でした。ソフトウェア開発においては、「機能としてはまだ使えるが、より良い代替手段があるため、使用を避けるべき（将来的に削除される可能性がある）」状態を指します。",
    "exampleSentence": "This method is deprecated and will be removed in the next version.",
    "exampleSentenceTranslation": "このメソッドは非推奨であり、次のバージョンで削除される予定です。",
    "synonyms": [
      { "term": "obsolete", "translation": "旧式の、廃れた（もう使えない）" },
      { "term": "outdated", "translation": "時代遅れの" },
      { "term": "disapproved", "translation": "不承認の" }
    ],
    "collocations": [
      { "term": "deprecated feature", "translation": "非推奨機能" },
      { "term": "mark as deprecated", "translation": "非推奨としてマークする" }
    ],
    "derivatives": ["deprecate", "deprecation"],
    "idioms": [],
    "nuance": "Obsoleteは「古くてもう使えない」ことが多いですが、Deprecatedは「今は動くが、使うべきではない（警告付き）」というニュアンスで、開発者への注意喚起として使われます。",
    "relatedWords": [
      { "term": "appreciate", "translation": "感謝する、価値を認める（逆の語源：ad-precari 値段をつける）" },
      { "term": "prayer", "translation": "祈り（precariに由来）" },
      { "term": "precarious", "translation": "不安定な（祈るしかないほど頼りない）" }
    ],
    "id": "tech-dep-002",
    "timestamp": 1700000000002,
    "status": "unknown"
  },
  {
    "word": "latency",
    "meaning": "潜伏、待ち時間、遅延",
    "pronunciation": "レイテンシー [ˈleɪtnsi]",
    "etymology": "ラテン語の latere（隠れている）に由来。",
    "mnemonic": "「霊（レイ）、点（ten）滅し（cy）てる間に遅れて見える」",
    "logic": "「隠れている状態」が原義です。データ通信において、リクエストを送ってから反応が返ってくるまでの「目に見えない待機時間」や「タイムラグ」を指すようになりました。",
    "exampleSentence": "Low latency is crucial for online gaming and video conferencing.",
    "exampleSentenceTranslation": "オンラインゲームやビデオ会議には低遅延が不可欠だ。",
    "synonyms": [
      { "term": "delay", "translation": "遅延" },
      { "term": "lag", "translation": "ラグ、遅れ" },
      { "term": "dormancy", "translation": "休眠状態" }
    ],
    "collocations": [
      { "term": "low latency", "translation": "低遅延" },
      { "term": "high latency", "translation": "高遅延" },
      { "term": "network latency", "translation": "ネットワーク遅延" }
    ],
    "derivatives": ["latent"],
    "idioms": [],
    "nuance": "Delayは一般的な「遅れ」ですが、Latencyはシステムやネットワークにおける「応答速度の性能指標」としての技術的な遅れを指します。",
    "relatedWords": [
      { "term": "latent", "translation": "潜在的な（隠れている）" },
      { "term": "latent talent", "translation": "秘めたる才能" }
    ],
    "id": "tech-lat-003",
    "timestamp": 1700000000003,
    "status": "unknown"
  }
];
