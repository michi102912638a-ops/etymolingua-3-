
export const BUSINESS_WORDS = [
  {
    "word": "leverage",
    "meaning": "活用する、てこの作用を利用する",
    "pronunciation": "レバレッジ [ˈlevərɪdʒ]",
    "etymology": "古フランス語の levier（持ち上げる）に由来。物理的な「てこ」の力から転じた。",
    "mnemonic": "「レバー（lever）でエッジ（edge）を効かせる」→ 小さな力で大きな効果を生むイメージ。",
    "logic": "物理的に重いものを動かす「てこ」のように、手持ちの資源や強みを最大限に活かして、より大きな成果（利益や有利な状況）を生み出すことを指します。",
    "exampleSentence": "We need to leverage our brand strength to enter the new market.",
    "exampleSentenceTranslation": "私たちはブランド力を活用して新しい市場に参入する必要がある。",
    "synonyms": [
      { "term": "utilize", "translation": "利用する" },
      { "term": "exploit", "translation": "（資源などを）開発する、利用する" },
      { "term": "capitalize on", "translation": "〜に乗じる、〜を活かす" }
    ],
    "collocations": [
      { "term": "leverage resources", "translation": "資源を活用する" },
      { "term": "high leverage", "translation": "高レバレッジ（借入比率が高い）" }
    ],
    "derivatives": ["lever", "leveraged"],
    "idioms": [],
    "nuance": "単に「使う(use)」のではなく、戦略的に有利な効果を得るために「最大限に活かす」というポジティブかつ戦略的な響きがあります。",
    "relatedWords": [
      { "term": "levitate", "translation": "空中浮遊する（軽くして持ち上げる）" },
      { "term": "alleviate", "translation": "軽減する（重荷を軽くする）" },
      { "term": "elevator", "translation": "エレベーター" }
    ],
    "id": "biz-leverage-001",
    "timestamp": 1700000000001,
    "status": "unknown"
  },
  {
    "word": "agenda",
    "meaning": "協議事項、議題、行動計画",
    "pronunciation": "アジェンダ [əˈdʒendə]",
    "etymology": "ラテン語の agere（行う）の未来受動分詞 agendum の複数形。「行われるべきこと」が原義。",
    "mnemonic": "「あ！(a) ジェンダ(genda)ー問題も議題に入れよう」",
    "logic": "「行う(agere)」べきことのリストであるため、会議で話し合って実行に移すべき項目や、政治的・個人的に達成したい裏の目的などを指すようになりました。",
    "exampleSentence": "What is the first item on the agenda for today's meeting?",
    "exampleSentenceTranslation": "今日の会議の議題の最初の項目は何ですか？",
    "synonyms": [
      { "term": "schedule", "translation": "予定" },
      { "term": "program", "translation": "計画" },
      { "term": "itinerary", "translation": "旅程" }
    ],
    "collocations": [
      { "term": "set the agenda", "translation": "議題を設定する" },
      { "term": "hidden agenda", "translation": "隠された意図・下心" }
    ],
    "derivatives": ["agent", "agency", "act"],
    "idioms": [
      { "term": "high on the agenda", "translation": "最優先課題で" }
    ],
    "nuance": "単なる予定表ではなく、「解決すべき課題」や「議論の進行表」というニュアンスが強いです。",
    "relatedWords": [
      { "term": "agent", "translation": "代理人（行う人）" },
      { "term": "action", "translation": "行動" },
      { "term": "agile", "translation": "機敏な" }
    ],
    "id": "biz-agenda-002",
    "timestamp": 1700000000002,
    "status": "unknown"
  },
  {
    "word": "consensus",
    "meaning": "合意、総意、意見の一致",
    "pronunciation": "コンセンサス [kənˈsensəs]",
    "etymology": "ラテン語の con-（共に）+ sentire（感じる）が語源。「皆が同じように感じること」。",
    "mnemonic": "「混戦（consen）さす（sus）ことなく、みんなで合意する」",
    "logic": "複数の人が「共に(con)」「感じる(sentire)」＝感覚や意見を共有することから、グループ全体での合意形成を意味します。",
    "exampleSentence": "It took hours to reach a consensus on the budget proposal.",
    "exampleSentenceTranslation": "予算案について合意に達するのに数時間かかった。",
    "synonyms": [
      { "term": "agreement", "translation": "合意" },
      { "term": "unanimity", "translation": "満場一致" },
      { "term": "accord", "translation": "一致、調和" }
    ],
    "collocations": [
      { "term": "reach a consensus", "translation": "合意に達する" },
      { "term": "build consensus", "translation": "合意を形成する（根回しする）" }
    ],
    "derivatives": ["consent", "sensible"],
    "idioms": [],
    "nuance": "100%の賛成（unanimity）でなくても、大多数が納得し、反対意見がない状態を含みます。日本的な「根回し」の結果としての合意によく使われます。",
    "relatedWords": [
      { "term": "sense", "translation": "感覚" },
      { "term": "sentiment", "translation": "感情" },
      { "term": "consent", "translation": "同意する" }
    ],
    "id": "biz-consensus-003",
    "timestamp": 1700000000003,
    "status": "unknown"
  }
];
