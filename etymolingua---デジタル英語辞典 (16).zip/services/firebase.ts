import { initializeApp, FirebaseApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { 
  getFirestore,
  initializeFirestore,
  collection, 
  getDocs, 
  setDoc, 
  doc, 
  deleteDoc, 
  updateDoc, 
  writeBatch,
  query,
  where,
  Timestamp,
  Firestore
} from "firebase/firestore";
import { 
  getAuth, 
  signInWithPopup, 
  signInWithRedirect,
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  User,
  Auth
} from "firebase/auth";
import { WordEntry, NoteEntry, BookMetadata } from "../types";

// =================================================================================
// Firebase Configuration
// =================================================================================
const firebaseConfig = {
  apiKey: "AIzaSyAoxYULcUrkyc3Y_uQ_0vMDm3CjO3ihGI4",
  authDomain: "etymolingua-61e6d.firebaseapp.com",
  projectId: "etymolingua-61e6d",
  storageBucket: "etymolingua-61e6d.firebasestorage.app",
  messagingSenderId: "483566326389",
  appId: "1:483566326389:web:76fe1c2b684f75484d1e3c",
  measurementId: "G-NP7E5T2Y08"
};

// --- Initialization Variables ---
let app: FirebaseApp | undefined;
let auth: Auth;
let db: Firestore;
let initializationError: string | null = null;

// --- Initialize Firebase Safely ---
try {
  if (!firebaseConfig.apiKey || firebaseConfig.apiKey.includes("YOUR_API_KEY")) {
    throw new Error("Firebase configuration is missing or invalid.");
  }

  app = initializeApp(firebaseConfig);

  if (typeof window !== 'undefined') {
    try {
      getAnalytics(app);
    } catch (e) {
      console.warn("Analytics initialization skipped:", e);
    }
  }

  db = initializeFirestore(app, {
    experimentalForceLongPolling: true,
  });
  
  auth = getAuth(app);

} catch (error: any) {
  console.error("Firebase Initialization Failed:", error);
  initializationError = error.message || "Failed to initialize Firebase.";
  
  // 型定義エラーを防ぐために二重キャストを使用
  auth = {} as unknown as Auth;
  db = {} as unknown as Firestore;
}

export { auth, db, initializationError };

// --- Auth Functions ---
export const login = async () => {
  if (initializationError) throw new Error(initializationError);
  if (!auth) throw new Error("Authentication not initialized");

  const provider = new GoogleAuthProvider();
  // アカウント選択を強制することで、自動ログインによるループ等の問題を軽減
  provider.setCustomParameters({
    prompt: 'select_account'
  });

  try {
    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error: any) {
    // ドメインエラー以外のログを出力
    if (error.code !== 'auth/unauthorized-domain') {
      console.error("Login failed:", error);
    }
    throw error;
  }
};

export const loginWithRedirect = async () => {
  if (initializationError) throw new Error(initializationError);
  if (!auth) throw new Error("Authentication not initialized");

  const provider = new GoogleAuthProvider();
  // アカウント選択を強制
  provider.setCustomParameters({
    prompt: 'select_account'
  });

  try {
    // リダイレクトを開始
    await signInWithRedirect(auth, provider);
    // 注意: ここでPromiseが解決しても、ページ遷移が発生するため後続処理は実行されない場合があります
  } catch (error: any) {
    console.error("Redirect Login failed:", error);
    throw error;
  }
}

export const logout = async () => {
  if (initializationError) return;
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Logout failed:", error);
    throw error;
  }
};

export const subscribeToAuth = (callback: (user: User | null) => void) => {
  if (initializationError) {
    return () => {}; 
  }
  return onAuthStateChanged(auth, callback);
};

// --- Memory Optimized Data Helper ---
const formatDoc = (docData: any): any => {
  if (!docData) return docData;
  const data = { ...docData };
  const toMillis = (val: any) => {
    if (val && typeof val.toMillis === 'function') return val.toMillis();
    if (val && typeof val.seconds === 'number') return val.seconds * 1000;
    return val;
  };
  if (data.timestamp) data.timestamp = toMillis(data.timestamp);
  if (data.createdAt) data.createdAt = toMillis(data.createdAt);
  if (data.updatedAt) data.updatedAt = toMillis(data.updatedAt);
  if (data.nextReviewDate) data.nextReviewDate = toMillis(data.nextReviewDate);
  return data;
};

// --- Local Storage Helper for Guest Mode ---
const GUEST_DB_KEY = 'etymolingua_guest_db';
const getLocalDB = () => {
  const data = localStorage.getItem(GUEST_DB_KEY);
  return data ? JSON.parse(data) : { words: [], books: [], notes: [] };
};
const saveLocalDB = (data: any) => {
  localStorage.setItem(GUEST_DB_KEY, JSON.stringify(data));
};

export const dbService = {
  async loadAll(userId?: string) {
    if (userId === 'guest') return getLocalDB();
    if (initializationError) throw new Error("Firebase not initialized");
    try {
      if (!userId) return { words: [], books: [], notes: [] };
      const wordsQuery = query(collection(db, "words"), where("userId", "==", userId));
      const wordsSnap = await getDocs(wordsQuery);
      const words = wordsSnap.docs.map(d => formatDoc(d.data()) as WordEntry);
      const booksQuery = query(collection(db, "books"), where("userId", "==", userId));
      const booksSnap = await getDocs(booksQuery);
      const books = booksSnap.docs.map(d => formatDoc(d.data()) as BookMetadata);
      const notesQuery = query(collection(db, "notes"), where("userId", "==", userId));
      const notesSnap = await getDocs(notesQuery);
      const notes = notesSnap.docs.map(d => formatDoc(d.data()) as NoteEntry);
      return { words, books, notes };
    } catch (error) {
      console.error("Error loading data from Firebase:", error);
      throw error;
    }
  },
  async addWord(word: WordEntry, userId?: string) {
    if (!userId) return; 
    if (userId === 'guest') {
      const db = getLocalDB();
      db.words.push({ ...word, userId });
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    try {
      const docData = { ...word, userId };
      await setDoc(doc(db, "words", word.id), docData);
    } catch (e) { console.error("Error adding word:", e); }
  },
  async updateWord(id: string, data: Partial<WordEntry>, userId?: string) {
    if (userId === 'guest') {
      const db = getLocalDB();
      db.words = db.words.map((w: WordEntry) => w.id === id ? { ...w, ...data, updatedAt: Date.now() } : w);
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    try {
      const docData = { ...data, updatedAt: Date.now() };
      if (userId) docData.userId = userId;
      await updateDoc(doc(db, "words", id), docData);
    } catch (e) { console.error("Error updating word:", e); }
  },
  async deleteWord(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.words.findIndex((w: WordEntry) => w.id === id);
    if (localIndex !== -1) {
       localDb.words[localIndex] = { ...localDb.words[localIndex], isTrashed: true, updatedAt: Date.now() };
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try { await updateDoc(doc(db, "words", id), { isTrashed: true, updatedAt: Date.now() }); } catch (e) { console.error("Error deleting word:", e); }
  },
  async restoreWord(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.words.findIndex((w: WordEntry) => w.id === id);
    if (localIndex !== -1) {
       localDb.words[localIndex] = { ...localDb.words[localIndex], isTrashed: false, updatedAt: Date.now() };
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try { await updateDoc(doc(db, "words", id), { isTrashed: false, updatedAt: Date.now() }); } catch (e) { console.error("Error restoring word:", e); }
  },
  async permanentDeleteWord(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.words.findIndex((w: WordEntry) => w.id === id);
    if (localIndex !== -1) {
       localDb.words.splice(localIndex, 1);
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try { await deleteDoc(doc(db, "words", id)); } catch (e) { console.error("Error permanent deleting word:", e); }
  },
  async saveWordsBatch(words: WordEntry[], userId?: string) {
    if (!userId) return;
    if (userId === 'guest') {
      const db = getLocalDB();
      words.forEach(newWord => {
        const idx = db.words.findIndex((w: WordEntry) => w.id === newWord.id);
        if (idx !== -1) db.words[idx] = { ...newWord, userId };
        else db.words.push({ ...newWord, userId });
      });
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    const batchSize = 500;
    for (let i = 0; i < words.length; i += batchSize) {
      const batch = writeBatch(db);
      const chunk = words.slice(i, i + batchSize);
      chunk.forEach(word => {
        const ref = doc(db, "words", word.id);
        const docData = { ...word, userId };
        batch.set(ref, docData);
      });
      await batch.commit();
    }
  },
  async addBook(book: BookMetadata, userId?: string) {
    if (!userId) return;
    if (userId === 'guest') {
      const db = getLocalDB();
      db.books.push({ ...book, userId });
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    try {
      const docData = { ...book, userId };
      await setDoc(doc(db, "books", book.id), docData);
    } catch (e) { console.error("Error adding book:", e); }
  },
  async updateBook(id: string, data: Partial<BookMetadata>, userId?: string) {
    if (userId === 'guest') {
      const db = getLocalDB();
      db.books = db.books.map((b: BookMetadata) => b.id === id ? { ...b, ...data } : b);
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    try {
      const docData = { ...data };
      if (userId) docData.userId = userId;
      await updateDoc(doc(db, "books", id), docData);
    } catch (e) { console.error("Error updating book:", e); }
  },
  async deleteBook(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.books.findIndex((b: BookMetadata) => b.id === id);
    if (localIndex !== -1) {
       localDb.books.splice(localIndex, 1);
       localDb.words = localDb.words.filter((w: WordEntry) => w.bookId !== id);
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try {
      await deleteDoc(doc(db, "books", id));
      const q = query(collection(db, "words"), where("bookId", "==", id));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();
    } catch (e) { console.error("Error deleting book:", e); }
  },
  async saveBooksBatch(books: BookMetadata[], userId?: string) {
    if (!userId) return;
    if (userId === 'guest') {
      const db = getLocalDB();
      books.forEach(newBook => {
        const idx = db.books.findIndex((b: BookMetadata) => b.id === newBook.id);
        if (idx !== -1) db.books[idx] = { ...newBook, userId };
        else db.books.push({ ...newBook, userId });
      });
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    const batch = writeBatch(db);
    books.forEach(book => {
      const ref = doc(db, "books", book.id);
      const docData = { ...book, userId };
      batch.set(ref, docData);
    });
    await batch.commit();
  },
  async addNote(note: NoteEntry, userId?: string) {
    if (!userId) return;
    if (userId === 'guest') {
      const db = getLocalDB();
      db.notes.push({ ...note, userId });
      saveLocalDB(db);
      return;
    }
    if (initializationError) return;
    try {
      const docData = { ...note, userId };
      await setDoc(doc(db, "notes", note.id), docData);
    } catch (e) { console.error("Error adding note:", e); }
  },
  async deleteNote(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.notes.findIndex((n: NoteEntry) => n.id === id);
    if (localIndex !== -1) {
       localDb.notes[localIndex] = { ...localDb.notes[localIndex], isTrashed: true, updatedAt: Date.now() };
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try { await updateDoc(doc(db, "notes", id), { isTrashed: true, updatedAt: Date.now() }); } catch (e) { console.error("Error deleting note:", e); }
  },
  async restoreNote(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.notes.findIndex((n: NoteEntry) => n.id === id);
    if (localIndex !== -1) {
       localDb.notes[localIndex] = { ...localDb.notes[localIndex], isTrashed: false, updatedAt: Date.now() };
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try { await updateDoc(doc(db, "notes", id), { isTrashed: false, updatedAt: Date.now() }); } catch (e) { console.error("Error restoring note:", e); }
  },
  async permanentDeleteNote(id: string) {
    const localDb = getLocalDB();
    const localIndex = localDb.notes.findIndex((n: NoteEntry) => n.id === id);
    if (localIndex !== -1) {
       localDb.notes.splice(localIndex, 1);
       saveLocalDB(localDb);
       return;
    }
    if (initializationError) return;
    try { await deleteDoc(doc(db, "notes", id)); } catch (e) { console.error("Error permanent deleting note:", e); }
  }
};